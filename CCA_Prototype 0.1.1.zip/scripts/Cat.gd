extends KinematicBody

var cat_name = "Барсик"
var coat = Color(0.16, 0.16, 0.18)
var is_player = false
var target = Vector3.ZERO
var wander_timer = 0.0
var scratch_timer = 0.0
var speed = 1.6
var player_direction = Vector3.ZERO
var body_mesh

func setup(n, c, player=false):
    cat_name = n
    coat = c
    is_player = player
    _build_cat()

func _build_cat():
    var mat = SpatialMaterial.new()
    mat.albedo_color = coat
    mat.roughness = 1.0

    body_mesh = MeshInstance.new()
    var body = SphereMesh.new()
    body.radius = 0.42
    body.height = 0.72
    body_mesh.mesh = body
    body_mesh.material_override = mat
    body_mesh.translation = Vector3(0, 0.48, 0)
    add_child(body_mesh)

    var head_mesh = MeshInstance.new()
    var head = SphereMesh.new()
    head.radius = 0.30
    head.height = 0.58
    head_mesh.mesh = head
    head_mesh.material_override = mat
    head_mesh.translation = Vector3(0, 0.92, -0.28)
    add_child(head_mesh)

    for side in [-1, 1]:
        var ear = MeshInstance.new()
        var cone = CylinderMesh.new()
        cone.top_radius = 0.0
        cone.bottom_radius = 0.12
        cone.height = 0.25
        ear.mesh = cone
        ear.material_override = mat
        ear.translation = Vector3(side * 0.19, 1.18, -0.30)
        add_child(ear)

    var tail_mesh = MeshInstance.new()
    var tail = CylinderMesh.new()
    tail.top_radius = 0.045
    tail.bottom_radius = 0.07
    tail.height = 0.62
    tail_mesh.mesh = tail
    tail.material_override = mat
    tail_mesh.translation = Vector3(0, 0.65, 0.43)
    tail_mesh.rotation_degrees.x = 65
    add_child(tail_mesh)

    var collision = CollisionShape.new()
    var shape = CapsuleShape.new()
    shape.radius = 0.32
    shape.height = 1.0
    collision.shape = shape
    collision.translation.y = 0.52
    add_child(collision)

func _physics_process(delta):
    scratch_timer = max(0.0, scratch_timer - delta)
    if is_player:
        if player_direction.length() > 0.05:
            var direction = player_direction.normalized()
            rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), delta * 9.0)
            move_and_slide(direction * 2.2, Vector3.UP)
            _keep_inside_room()
        return

    wander_timer -= delta
    if wander_timer <= 0.0:
        wander_timer = rand_range(1.5, 4.0)
        target = Vector3(rand_range(-4.5, 4.5), 0, rand_range(-4.5, 4.5))
    var direction_to_target = target - global_transform.origin
    direction_to_target.y = 0
    if direction_to_target.length() > 0.18:
        var direction = direction_to_target.normalized()
        rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), delta * 5.0)
        move_and_slide(direction * speed * 0.65, Vector3.UP)
        _keep_inside_room()

func _keep_inside_room():
    var p = global_transform.origin
    p.x = clamp(p.x, -6.0, 6.0)
    p.z = clamp(p.z, -6.0, 6.0)
    global_transform.origin = p

func do_scratch():
    if scratch_timer > 0.0:
        return
    scratch_timer = 0.7
    if body_mesh:
        body_mesh.scale = Vector3(1.12, 0.9, 1.12)
    yield(get_tree().create_timer(0.22), "timeout")
    if body_mesh:
        body_mesh.scale = Vector3.ONE
