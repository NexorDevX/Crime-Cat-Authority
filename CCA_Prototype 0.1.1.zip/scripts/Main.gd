extends Spatial

const CatScript = preload("res://scripts/Cat.gd")
var cats = []
var active_index = 0
var move_vector = Vector2.ZERO
var joystick_touch = -1
var camera_touch = -1
var last_camera_pos = Vector2.ZERO
var camera_yaw = 0.0
var camera_pitch = -0.42
var camera_distance = 8.0
var status_label
var switch_button
var scratch_button
var joystick_base
var joystick_knob
var camera_node
var hud

func _ready():
    randomize()
    camera_node = get_node("PlayerCamera")
    hud = get_node("CanvasLayer/HUD")
    _create_cats()
    _build_hud()
    _update_active()

func _create_cats():
    var definitions = [
        ["Барсик", Color(0.78,0.76,0.70)],
        ["Гера", Color(0.10,0.10,0.12)],
        ["Кузя", Color(0.28,0.22,0.18)]
    ]
    for i in range(definitions.size()):
        var cat = CatScript.new()
        cat.setup(definitions[i][0], definitions[i][1], i == 0)
        cat.translation = Vector3(-2.0 + i * 2.0, 0, 0)
        get_node("Cats").add_child(cat)
        cats.append(cat)

func _build_hud():
    status_label = Label.new()
    status_label.rect_position = Vector2(16, 12)
    status_label.add_color_override("font_color", Color(1,1,1))
    status_label.add_color_override("font_color_shadow", Color(0,0,0))
    status_label.text = "CCA • 0.1"
    hud.add_child(status_label)

    switch_button = Button.new()
    switch_button.text = "Сменить кота"
    switch_button.rect_position = Vector2(16, 48)
    switch_button.rect_size = Vector2(150, 48)
    switch_button.connect("pressed", self, "_switch_cat")
    hud.add_child(switch_button)

    scratch_button = Button.new()
    scratch_button.text = "Царапаться"
    scratch_button.rect_position = Vector2(174, 48)
    scratch_button.rect_size = Vector2(130, 48)
    scratch_button.connect("pressed", self, "_scratch")
    hud.add_child(scratch_button)

    var hint = Label.new()
    hint.text = "WASD — ходьба • Tab — смена кота • Space — царапаться"
    hint.rect_position = Vector2(16, 104)
    hint.add_color_override("font_color", Color(1,1,1))
    hud.add_child(hint)

    joystick_base = ColorRect.new()
    joystick_base.color = Color(0.1,0.1,0.1,0.35)
    joystick_base.rect_position = Vector2(35, 330)
    joystick_base.rect_size = Vector2(120,120)
    hud.add_child(joystick_base)

    joystick_knob = ColorRect.new()
    joystick_knob.color = Color(0.9,0.9,0.9,0.65)
    joystick_knob.rect_position = Vector2(75, 370)
    joystick_knob.rect_size = Vector2(40,40)
    hud.add_child(joystick_knob)

    var touch_hint = Label.new()
    touch_hint.text = "Левый стик: движение • Проведи пальцем справа: камера"
    touch_hint.rect_position = Vector2(320, 470)
    touch_hint.add_color_override("font_color", Color(1,1,1))
    hud.add_child(touch_hint)

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < 210 and event.position.y > 260:
                joystick_touch = event.index
                _set_joystick(event.position)
            else:
                camera_touch = event.index
                last_camera_pos = event.position
        else:
            if event.index == joystick_touch:
                joystick_touch = -1
                move_vector = Vector2.ZERO
                joystick_knob.rect_position = Vector2(75,370)
            if event.index == camera_touch:
                camera_touch = -1
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch:
            _set_joystick(event.position)
        elif event.index == camera_touch:
            var delta_pos = event.position - last_camera_pos
            camera_yaw -= delta_pos.x * 0.006
            camera_pitch = clamp(camera_pitch - delta_pos.y * 0.003, -0.85, -0.12)
            last_camera_pos = event.position

func _set_joystick(pos):
    var center = Vector2(95,390)
    var v = (pos - center) / 48.0
    if v.length() > 1:
        v = v.normalized()
    move_vector = v
    joystick_knob.rect_position = center + v * 38 - Vector2(20,20)

func _process(delta):
    if cats.empty():
        return
    var cat = cats[active_index]
    var input_vec = move_vector
    if Input.is_action_pressed("move_forward"): input_vec.y -= 1
    if Input.is_action_pressed("move_back"): input_vec.y += 1
    if Input.is_action_pressed("move_left"): input_vec.x -= 1
    if Input.is_action_pressed("move_right"): input_vec.x += 1
    if input_vec.length() > 1:
        input_vec = input_vec.normalized()
    var forward = Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
    var right = Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
    var direction = right * input_vec.x + forward * -input_vec.y
    cat.player_direction = direction.normalized() if direction.length() > 0.05 else Vector3.ZERO
    if Input.is_action_just_pressed("switch_cat"):
        _switch_cat()
    if Input.is_action_just_pressed("scratch"):
        _scratch()
    _update_camera(delta)

func _update_camera(delta):
    var target = cats[active_index].global_transform.origin + Vector3(0,0.7,0)
    var offset = Vector3(sin(camera_yaw) * camera_distance, 3.0, cos(camera_yaw) * camera_distance)
    offset.y = -sin(camera_pitch) * camera_distance + 1.0
    var desired = target + offset
    camera_node.translation = camera_node.translation.linear_interpolate(desired, delta * 5.0)
    camera_node.look_at(target, Vector3.UP)

func _switch_cat():
    cats[active_index].is_player = false
    active_index = (active_index + 1) % cats.size()
    cats[active_index].is_player = true
    _update_active()

func _update_active():
    if status_label:
        status_label.text = "CCA • Играешь за: " + cats[active_index].cat_name

func _scratch():
    cats[active_index].do_scratch()
    var player = cats[active_index]
    for cat in cats:
        if cat != player and cat.global_transform.origin.distance_to(player.global_transform.origin) < 1.5:
            cat.do_scratch()
